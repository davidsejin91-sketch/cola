/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.cola;

/**
 *
 * @author Estudiante
 */
import java.util.ArrayDeque;
import java.util.Queue;
import java.util.Deque;
import java.util.PriorityQueue;

public class Cola {

    public static void main(String[] args) {
        System.out.println("Ejercicios Colas con libreria de Java\n");
        Colasimple();
        ColasCircular();
        ColasPrioridad();
        ColasDoble();
    }
    static void Colasimple(){
    System.out.println("Ejercicios Colas simple:primero en llegar primero en salir ");
    
    Queue<String> java = new ArrayDeque<>();
    java.offer("ANA");
    java.offer("VIVIANA");
    java.offer("Leiner");
    System.out.println("Java :   " + java.poll() + " , " + java.poll()+ "\n");
    
    }
    
    static void ColasCircular(){
    System.out.println("Ejercicios Colas Circular:Reutiliza Los espacios del Arreglo ");
    
    Queue<String> java = new ArrayDeque<>();
    java.offer("ANA");
    java.offer("VIVIANA");
    java.offer("Leiner");
    System.out.println("SALE :   " + java.poll());
    java.offer("FABIO");
    System.out.println("Java :   " + java.poll() + " , " + java.poll() + ", " + java.poll() + "\n");
    
    }
    
    static void ColasPrioridad(){
    System.out.println("Ejercicios Colas Prioridad:El menor nuero se atiende primero ");
    
    Queue<Integer> java = new PriorityQueue<>();
    java.offer(5);
    java.offer(2);
    java.offer(3);
    
    System.out.println("Java :   " + java.poll() + " , " + java.poll() + ", " + java.poll() + "\n");
    
    }
    
     static void ColasDoble(){
    System.out.println("ColasDoble(DEQUE): Permite usar ambos extremos ");
    
    Deque<String> java = new ArrayDeque<>();
    java.offerLast("ANA");
    java.offerLast("VIVIANA");
    java.offerFirst("LEINER");
    
    System.out.println("Java : Sale del Inicio  " + java.pollFirst() + " ,Sale del final " + java.pollLast() );
    
    }
    
}